package org.example.model;

public enum StatoToDo {
    COMPLETATO,
    NONCOMPLETATO
}
